package appli;

import hash.FENGHashTable; // remplacer YOUR par tes initiales

public class Exo2 {
    public static void main(String[] args) {

        FENGHashTable<String, String> table = new FENGHashTable<String, String>();


        table.put("two", "deux");
        table.put("four", "quatre");


        System.out.println(table.get("two"));
        System.out.println(table.get("deux"));


        System.out.println(table);
    }



}