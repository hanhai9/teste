package hash;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Generic hash table implementation, mapping keys to values.
 * 
 * @param <K>
 *            the type of the keys
 * @param <V>
 *            the type of the values
 */
public class FENGHashTable<K, V> {

	protected List<Mapping<K, V>>[] table;

	protected int size;

    /**
     * Construct an empty hashtable with an initial capacity of 4.
     */
    public FENGHashTable() {
        size = 0;
        table = (List<Mapping<K, V>>[]) new List[4];
        for (int i = 0; i < 4; i++) {
            table[i] = new ArrayList<Mapping<K, V>>();
        }
    }

	/**
	 * Associate the specified value with the specified key in this map. If the
	 * map previously contained a mapping for the key, the old value is
	 * replaced.
	 * 
	 * @param cle
	 *            key with which the specified value is to be associated
	 * @param valeur
	 *            value to be associated with the specified key
	 * @return the previous value associated with <tt>key</tt>, or <tt>null</tt>
	 *         if there was no mapping for <tt>key</tt>.
	 * @throws NullPointerException
	 *             if the key or the value is <tt>null</tt>
	 */
    public V put(K cle, V valeur) {
        if (cle == null || valeur == null) throw new NullPointerException();
        if ((size + 1) * 100 / table.length >= 80) {
            agrandir();
        }

        int indice = Math.floorMod(cle.hashCode(), table.length);
        for (Mapping<K, V> truc : table[indice]) {
            if (truc.getKey().equals(cle)) {
                V ancien = truc.getValue();
                truc.setValue(valeur);
                return ancien;
            }
        }
        table[indice].add(new Mapping<K, V>(cle, valeur));
        size++;
        return null;
    }

	/**
	 * Return the value to which the specified key is mapped, or <tt>null</tt>
	 * if this map contains no mapping for the key.
	 * 
	 * @param key
	 *            the key whose associated value is to be returned
	 * @return the value to which the specified key is mapped, or <tt>null</tt>
	 *         if this map contains no mapping for the key
	 * @throws NullPointerException
	 *             if the key is <tt>null</tt>
	 */
	public V get(Object key) {
        if (key == null) throw new NullPointerException();
        int index = Math.floorMod(key.hashCode(), table.length);
        for (Mapping<K, V> m : table[index]) {
            if (m.getKey().equals(key)) {
                return m.getValue();
            }
        }
        return null;
    }

    @Override
    public String toString() {
        String res = "{";
        Iterator<Mapping<K, V>> it = this.iterator();
        while (it.hasNext()) {
            res += it.next();
            if (it.hasNext()) {
                res += ", ";
            }
        }
        res += "}";
        return res;
    }

    private void agrandir() {
        List<Mapping<K, V>>[] vieuxTableau = table;
        table = (List<Mapping<K, V>>[]) new List[vieuxTableau.length * 2];
        for (int i = 0; i < table.length; i++) {
            table[i] = new ArrayList<Mapping<K, V>>();
        }
        size = 0;
        for (List<Mapping<K, V>> seau : vieuxTableau) {
            for (Mapping<K, V> truc : seau) {
                put(truc.getKey(), truc.getValue());
            }
        }
    }

    public Iterator<Mapping<K, V>> iterator() {
        return new HashIterator(table);
    }

    private class HashIterator implements Iterator<Mapping<K, V>> {
        private int indiceSeau;
        private int indiceTruc;
        private List<Mapping<K, V>>[] tab;

        public HashIterator(List<Mapping<K, V>>[] t) {
            tab = t;
            indiceSeau = 0;
            indiceTruc = 0;
            avancer();
        }

        public HashIterator() {
            this(table);
        }

        private void avancer() {
            while (indiceSeau < tab.length && indiceTruc >= tab[indiceSeau].size()) {
                indiceSeau++;
                indiceTruc = 0;
            }
        }

        @Override
        public boolean hasNext() {
            return indiceSeau < tab.length;
        }

        @Override
        public Mapping<K, V> next() {
            Mapping<K, V> m = tab[indiceSeau].get(indiceTruc);
            indiceTruc++;
            avancer();
            return m;
        }
    }


	}

