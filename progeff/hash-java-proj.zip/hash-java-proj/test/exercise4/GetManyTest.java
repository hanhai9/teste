package exercise4;

import hash.FENGHashTable;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class GetManyTest {

	@Test
	public void run() {
        FENGHashTable<String, String> h = new FENGHashTable<>();
        assertNull(h.get("Y"));
		h.put("M", "m");
        assertNull(h.get("Y"));
		assertEquals("m", h.get("M"));
		h.put("C", "c");
        assertNull(h.get("Y"));
		assertEquals("m", h.get("M"));
		assertEquals("c", h.get("C"));
		h.put("M", "n");
        assertNull(h.get("Y"));
		assertEquals("n", h.get("M"));
		assertEquals("c", h.get("C"));
	}

}
