package exercise4;

import utils.OpenHashTable;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class PutManyTest {

	public static <K, V> void put(OpenHashTable<K, V> h, K key, V value,
                                  V expectedPrevious) {
		int size_bef = h.size();
		V prev = h.put(key, value);
		if (expectedPrevious == null) {
			assertNull(prev,
                    "When adding a new entry, put should return null");
			assertEquals(size_bef + 1, h.size(),
                    "When adding a new entry, the size should be increased by one");
		} else {
			assertEquals(expectedPrevious, prev,
                    "When updating an entry, put should return the old value");
			assertEquals(size_bef, h.size(),
                    "When updating an entry, the size should be unchanged");
		}
		h.check();
	}

	@Test
	public void run() {
		OpenHashTable<String, Integer> h = new OpenHashTable<>();
		put(h, "A", 1, null);
		put(h, "B", 2, null);
		put(h, "C", 1, null);
		put(h, "A", 4, 1);
		put(h, "A", 0, 4);
		put(h, "Hello", 9, null);
	}
}
