package exercise4;

import hash.FENGHashTable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GetTest {

    FENGHashTable<String, String> h;

	@BeforeEach
	public void setup() {
		h = new FENGHashTable<>();
	}

	@Test
	public void emptyTableGivesNull() {
		assertNull(h.get("Hello"),
                "Getting a key from an empty table should return null");
	}

	@Test
	public void absentKeyGivesNull() {
		h.put("Hello", "World");
		assertNull(h.get("World"),
                "Getting an absent key should return null");
	}

	@Test
	public void identicalKeyGivesTheValue() {
		String k = "Here";
		String v = "we are!";
		h.put(k, v);
		assertEquals(v, h.get(k));
	}

	@Test
	public void equalKeyGivesTheValue() {
		String k1 = "Why";
		String k2 = new String(k1);  // Different object; same text.
		String v = "not";
		assertNotSame(k1, k2);
		assertEquals(k1, k2);
		h.put(k1, v);
		assertEquals(v, h.get(k2));
	}

	@Test
	public void negativeHashCodeFound() {
		String k = "Supercalifragilisticexpialidocious";
		String v = "Mary Poppins";
		h.put(k, v);
		assertEquals(v, h.get(k));
	}

}
