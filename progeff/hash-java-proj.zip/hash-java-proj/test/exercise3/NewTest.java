package exercise3;

import utils.OpenHashTable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class NewTest {

	OpenHashTable<?, ?> h;

	@BeforeEach
	public void setup() {
		h = new OpenHashTable<>();
	}

	@Test
	public void initialSizeIsZero() {
		assertEquals(0, h.size(),
                "The size of the new " + h.classUnderTest() + " is invalid.");
	}

	@Test
	public void initialTableIsNotNull() {
		assertNotNull(h.table(),
                "The table of the new " + h.classUnderTest() + " should not be null.");
	}

	@Test
	public void initialTableCapacityIsFour() {
		assertEquals(4,
				h.table().length, "The capacity of the table is invalid.");
	}

	@Test
	public void initialTableCellsAreNotNull() {
		for (int i = 0; i < h.table().length; i++) {
			assertNotNull(h.table()[i],
                    "The list at index " + i + " of the table should not be null.");
		}
	}

	@Test
	public void initialTableCellsAreEmpty() {
		for (int i = 0; i < h.table().length; i++) {
			assertTrue(h.table()[i].isEmpty(),
                    "The list at index " + i + " of the table should be empty.");
		}
	}

	@Test
	public void initialTableCellsAreDistinct() {
		assertNotSame(h.table()[0], h.table()[1],
				"First and second table cells should not reference the same list");
	}
}
