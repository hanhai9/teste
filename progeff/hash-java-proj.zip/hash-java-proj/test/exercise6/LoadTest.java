package exercise6;

import utils.OpenHashTable;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class LoadTest {

	@Test
	public void run() {
		OpenHashTable<String, Integer> h = new OpenHashTable<>();
		for (int i = 1; i < 1000; i++) {
			h.put(String.valueOf(i), i);
			assertEquals(i, h.size(),
                    "Bad size");
			h.check();
			double load = (h.size() * 100.) / h.table().length;
			assertTrue(load < 80.,
                    "Table reached " + load + "% after " + i + " values added");
		}
	}

}
