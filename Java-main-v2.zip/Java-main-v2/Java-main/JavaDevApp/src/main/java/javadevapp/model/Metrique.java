package javadevapp.model;

public class Metrique {
    private String algo;
    private double attente;
    private double reponse;
    private double makespan;

    public Metrique(String algo, double attente, double reponse, double makespan) {
        this.algo = algo;
        this.attente = attente;
        this.reponse = reponse;
        this.makespan = makespan;
    }

    // Getter pour algo
    public String getAlgo() {
        return algo;
    }

    // Getter pour attente
    public double getAttente() {
        return attente;
    }

    // Getter pour reponse
    public double getReponse() {
        return reponse;
    }

    // Getter pour makespan
    public double getMakespan() {
        return makespan;
    }
}

