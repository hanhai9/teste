package javadevapp;

/**
 * La classe Main qui lance l'application JavaDevApp
 */
public class Main {
	public static void main(String[] args) {
		JavaDevApp.main(args);
	}
}
