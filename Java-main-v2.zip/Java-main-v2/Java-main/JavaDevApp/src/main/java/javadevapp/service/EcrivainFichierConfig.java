package javadevapp.service;

import javadevapp.model.ConfigOrdonnanceur;
import java.io.*;

public class EcrivainFichierConfig {

    /**
     * Crée le fichier config.txt avec les paramètres de configuration
     * Le fichier est créé dans le même dossier que le fichier de métriques
     *
     * @throws IOException s'il y a une erreur d'écriture
     */
    public static void creerFichierConfig(ConfigOrdonnanceur config) throws IOException {
        // Récupérer le dossier du fichier de métriques
        String baseMetrics = config.getFichierMetriques();
        File metricsFile = new File(baseMetrics);
        File dir = metricsFile.getParentFile();
        if (dir == null) {
            dir = new File("."); // fallback si pas de parent
        }

        // Créer le fichier config.txt dans ce dossier
        File cheminConfig = new File(dir, "config.txt");

        try (PrintWriter writer = new PrintWriter(cheminConfig)) {
            writer.println("# Fichier de configuration pour l'ordonnanceur Python");
            writer.println();
            writer.println("# Chemin vers le fichier CSV des processus");
            writer.println("process_file = " + config.getFichierProcessus());
            writer.println();
            writer.println("# Chemin vers le fichier qui contient les ressources disponibles");
            writer.println("ressources_file = " + config.getFichierRessources());
            writer.println();
            writer.println("# Fichiers où stocker les résultats pour chaque algorithme");

            writer.println("result_file_fifo = " + new File(dir, "resultat_fifo.csv").getAbsolutePath());
            writer.println("result_file_rr = " + new File(dir, "resultat_rr.csv").getAbsolutePath());
            writer.println("result_file_priorite = " + new File(dir, "resultat_priorite.csv").getAbsolutePath());
            writer.println();
            writer.println("# Fichier où stocker les métriques globales");
            writer.println("metrics_file = " + config.getFichierMetriques());
            writer.println();
            writer.println("# Algorithmes à exécuter (FIFO, RR et PRIORITE)");
            writer.println("algorithms = " + config.getAlgorithme());
            writer.println();
            writer.println("# Quantum pour Round Robin (en unités de temps)");
            writer.println("quantum = " + (config.getQuantum() != null ? config.getQuantum() : 2));
        }

        // Stocker le chemin pour l'utiliser dans executerPython
        System.setProperty("python.config.path", cheminConfig.getAbsolutePath());
    }
}
