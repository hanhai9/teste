package javadevapp.view;

import javadevapp.model.ConfigOrdonnanceur;
import javadevapp.model.Metrique;
import javadevapp.service.ConfigValidator;
import javadevapp.service.MetriqueService;
import javadevapp.service.EcrivainFichierConfig;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.layout.VBox;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Contrôleur principal de l'interface de configuration de l'ordonnanceur.
 * <p>
 * Responsabilités :
 * <ul>
 * <li>Gestion des sélecteurs de fichiers</li>
 * <li>Validation de la configuration via {@link ConfigValidator}</li>
 * <li>Création du fichier config.txt via {@link EcrivainFichierConfig}</li>
 * <li>Exécution du script Python via {@link ExecuteurPython}</li>
 * <li>Lecture et affichage des métriques via {@link MetriqueService}</li>
 * </ul>
 */
public class ConfigOrdonnanceurController implements Initializable {

    @FXML
    private Label cheminProcess;
    @FXML
    private VBox graphiqueBox;
    @FXML
    private Label cheminRessources;
    @FXML
    private Label cheminBackupMetrique;
    @FXML
    private CheckBox FIFO;
    @FXML
    private CheckBox PRIORITE;
    @FXML
    private CheckBox RR;
    @FXML
    private TextField txtQuantum;

    @FXML
    private Button btnListeProcessus;
    @FXML
    private Button btnInfoProcessus;
    @FXML
    private Button btnDiagrammeGantt;
    @FXML
    private Button btnTemps;
    @FXML
    private Button btnProcesseur;
    @FXML
    private Button btnMetriques;

    private ConfigOrdonnanceur config;

    private Stage metriqueStage;
    private VBox metriqueRoot;

    public ConfigOrdonnanceurController() {
        this.config = new ConfigOrdonnanceur();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cheminProcess.setText("Aucun fichier sélectionné");
        cheminRessources.setText("Aucun fichier sélectionné");
        cheminBackupMetrique.setText("Aucun fichier sélectionné");
        txtQuantum.setDisable(true);

        RR.selectedProperty().addListener((obs, oldVal, newVal) -> {
            txtQuantum.setDisable(!newVal);
            if (!newVal)
                txtQuantum.clear();
        });
    }

    @FXML
    private void actionChoisirProcessus() {
        FileChooser choixProcess = new FileChooser();
        choixProcess.setTitle("Sélectionner le fichier des processus");
        choixProcess.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Fichiers CSV", "*.csv"));
        File process = choixProcess.showOpenDialog(cheminProcess.getScene().getWindow());
        if (process != null) {
            config.setFichierProcessus(process.getAbsolutePath());
            cheminProcess.setText(process.getAbsolutePath());
        }
    }

    @FXML
    private void actionChoisirRessources() {
        FileChooser choixRessources = new FileChooser();
        choixRessources.setTitle("Sélectionner le fichier des ressources");
        choixRessources.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Fichiers texte", "*.txt"));
        File ressources = choixRessources.showOpenDialog(cheminRessources.getScene().getWindow());
        if (ressources != null) {
            config.setFichierRessources(ressources.getAbsolutePath());
            cheminRessources.setText(ressources.getAbsolutePath());
        }
    }

    @FXML
    private void actionChoisirMetriques() {
        FileChooser choixMetriques = new FileChooser();
        choixMetriques.setTitle("Sélectionner le fichier de sortie des métriques");
        choixMetriques.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Fichiers texte", "*.txt"));
        File metriques = choixMetriques.showSaveDialog(cheminBackupMetrique.getScene().getWindow());
        if (metriques != null) {
            config.setFichierMetriques(metriques.getAbsolutePath());
            cheminBackupMetrique.setText(metriques.getAbsolutePath());
        }
    }

    @FXML
    private void actionSauvegarder() {
        ConfigValidator validator = new ConfigValidator();
        String erreurs = validator.validerConfiguration(
                config,
                FIFO.isSelected(),
                PRIORITE.isSelected(),
                RR.isSelected(),
                txtQuantum.getText());

        if (!erreurs.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Configuration incomplète");
            alert.setHeaderText("Veuillez corriger les erreurs suivantes :");
            alert.setContentText(erreurs);
            alert.showAndWait();
            return;
        }

        StringBuilder algos = new StringBuilder();
        if (FIFO.isSelected())
            algos.append("FIFO,");
        if (PRIORITE.isSelected())
            algos.append("PRIORITE,");
        if (RR.isSelected())
            algos.append("RR,");
        if (algos.length() > 0) {
            algos.setLength(algos.length() - 1);
            config.setAlgorithme(algos.toString());
        }

        if (RR.isSelected() && !txtQuantum.getText().isEmpty()) {
            try {
                config.setQuantum(Integer.parseInt(txtQuantum.getText()));
            } catch (NumberFormatException e) {
                config.setQuantum(2);
            }
        }

        try {
            EcrivainFichierConfig.creerFichierConfig(config);

            try (PrintWriter pw = new PrintWriter(config.getFichierMetriques())) {
            }

            new Thread(() -> {
                try {
                    executerPython(); // attend la fin du script Python
                    MetriqueService metriqueService = new MetriqueService();
                    List<Metrique> metriques = metriqueService.lireMetriquesDepuisFichier(config.getFichierMetriques());
                    BarChart<String, Number> chart = metriqueService.creerDiagramme(metriques);

                    javafx.application.Platform.runLater(() -> {
                        // si la fenêtre métriques est ouverte, rafraîchir
                        if (metriqueStage != null && metriqueStage.isShowing()) {
                            metriqueRoot.getChildren().setAll(chart);
                        }
                    });
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();

            btnListeProcessus.setDisable(false);
            btnInfoProcessus.setDisable(false);
            btnDiagrammeGantt.setDisable(false);
            btnTemps.setDisable(false);
            btnProcesseur.setDisable(false);
            btnMetriques.setDisable(false);

        } catch (

        IOException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
    }

    /**
     * Exécute le script Python main.py
     * Extrait les ressources Python du .JAR dans un répertoire temporaire
     * 
     * @throws IOException s'il y a une erreur lors de l'exécution
     */
    private void executerPython() throws IOException, InterruptedException {
        // Récupère le script 'python/main.py' depuis les ressources
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("python/main.py")) {
            if (inputStream == null) {
                throw new IOException("Impossible de trouver main.py dans les ressources.");
            }

            // Vérifier qu'au moins un algorithme est sélectionné
            boolean algoSelected = FIFO.isSelected() || PRIORITE.isSelected() || RR.isSelected();
            if (!algoSelected) {
                return;
            }

            // Créer le processus Python
            ProcessBuilder pb = new ProcessBuilder("python", "-");
            Process process = pb.start();

            // Thread pour lire stdout
            Thread stdoutReader = new Thread(() -> {
                try (InputStream is = process.getInputStream()) {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = is.read(buf)) != -1) {
                        System.out.write(buf, 0, r);
                    }
                } catch (IOException ignored) {
                }
            }, "python-stdout-reader");
            stdoutReader.setDaemon(true);
            stdoutReader.start();

            // Thread pour lire stderr (important pour voir les erreurs Python)
            Thread stderrReader = new Thread(() -> {
                try (InputStream es = process.getErrorStream()) {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = es.read(buf)) != -1) {
                        System.err.write(buf, 0, r);
                    }
                } catch (IOException ignored) {
                }
            }, "python-stderr-reader");
            stderrReader.setDaemon(true);
            stderrReader.start();

            // Créer un répertoire temporaire pour les modules Python
            Path tempPython = Files.createTempDirectory("python-modules");
            tempPython.toFile().deleteOnExit();

            // Extraire les modules Python du JAR
            String[] modulesPython = {
                    "python/entre_sortie.py",
                    "python/ordonnanceurs.py",
                    "python/metrique.py"
            };

            for (String cheminPython : modulesPython) {
                try (InputStream res = getClass().getClassLoader().getResourceAsStream(cheminPython)) {
                    if (res != null) {
                        String fileName = cheminPython.substring(cheminPython.lastIndexOf('/') + 1);
                        Path targetFile = tempPython.resolve(fileName);
                        Files.copy(res, targetFile, StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }

            // Copier aussi le fichier config.txt créé dynamiquement
            String configConfig = System.getProperty("python.config.path");
            if (configConfig != null) {
                Path sourceConfig = Path.of(configConfig);
                Path targetConfig = tempPython.resolve("config.txt");
                Files.copy(sourceConfig, targetConfig, StandardCopyOption.REPLACE_EXISTING);
            }

            // Envoyer le contenu du script dans stdin du process
            try (OutputStream procIn = process.getOutputStream()) {
                // Injecter du code Python pour configurer sys.path
                String setupCode = String.format(
                        "import sys%nsys.path.insert(0, '%s')%n",
                        tempPython.toString().replace("\\", "\\\\"));
                procIn.write(setupCode.getBytes());
                procIn.flush();

                // Puis envoyer le contenu du script main.py
                byte[] buffer = new byte[8192];
                int len;
                while ((len = inputStream.read(buffer)) != -1) {
                    procIn.write(buffer, 0, len);
                }
                procIn.flush();
            }

            // Attendre la fin du processus Python
            int exitCode = process.waitFor();
            System.out.println("Python terminé avec code " + exitCode);
        }

    }

    @FXML
    private void actionAfficherMetriques() {
        if (metriqueStage == null) {
            metriqueStage = new Stage();
            metriqueRoot = new VBox();
            Scene scene = new Scene(metriqueRoot, 600, 400);
            metriqueStage.setTitle("Métriques");
            metriqueStage.setScene(scene);
        }
        rafraichirMetriques(); // 🔑 recharge les données
        metriqueStage.show();
    }

    private void rafraichirMetriques() {
        try {
            MetriqueService metriqueService = new MetriqueService();
            List<Metrique> metriques = metriqueService.lireMetriquesDepuisFichier(config.getFichierMetriques());

            if (metriques.isEmpty()) {
                Label vide = new Label("Aucune métrique disponible pour l'instant.");
                metriqueRoot.getChildren().setAll(vide);
                return;
            }

            BarChart<String, Number> chart = metriqueService.creerDiagramme(metriques);
            metriqueRoot.getChildren().setAll(chart);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}