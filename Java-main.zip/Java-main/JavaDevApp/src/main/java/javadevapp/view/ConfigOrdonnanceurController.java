package javadevapp.view;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javadevapp.model.ConfigOrdonnanceur;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

/**
 * Contrôleur de l'interface de config de l'ordonnanceur (de l'application).
 * Il gère le choix de fichiers, données et l'exécution du script Python
 */
public class ConfigOrdonnanceurController implements Initializable {
    
    @FXML
    private Label cheminProcess;

    @FXML
    private VBox graphiqueBox;

    @FXML
    private Label cheminRessources;
    @FXML
    private Label cheminBackupMetrique;
    
    @FXML
    private CheckBox FIFO;
    @FXML
    private CheckBox PRIORITE;
    @FXML
    private CheckBox RR;
    
    @FXML
    private TextField txtQuantum;
    
    private ConfigOrdonnanceur config;
    
    /**
     * Constructeur par défaut
     * Initialise la config de l'ordonnanceur
     */
    public ConfigOrdonnanceurController() {
        this.config = new ConfigOrdonnanceur();
    }
    
    /**
     * Initialise le contrôleur et configure les valeurs par défaut
     * 
     * @param location l'URL de localisation du FXML
     * @param resources les ressources utilisées
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cheminProcess.setText("Aucun fichier sélectionné");
        cheminRessources.setText("Aucun fichier sélectionné");
        cheminBackupMetrique.setText("Aucun fichier sélectionné");
        
        txtQuantum.setDisable(true);
        
        RR.selectedProperty().addListener((obs, oldVal, newVal) -> {
            txtQuantum.setDisable(!newVal);
            if (!newVal) {
                txtQuantum.clear();
            }
        });
    }
    
    /**
     * Ouvre un sélecteur de fichier pour choisir le fichier CSV des processus
     */
    @FXML
    private void actionChoisirProcessus() {
        FileChooser choixProcess = new FileChooser();
        choixProcess.setTitle("Sélectionner le fichier des processus");
        choixProcess.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Fichiers CSV", "*.csv")
        );
        
        File process = choixProcess.showOpenDialog(cheminProcess.getScene().getWindow());
        if (process != null) {
            config.setFichierProcessus(process.getAbsolutePath());
            cheminProcess.setText(process.getAbsolutePath());
        }
    }
    
    /**
     * Ouvre un sélecteur de fichier pour choisir le fichier des ressources
     */
    @FXML
    private void actionChoisirRessources() {
        FileChooser choixRessources = new FileChooser();
        choixRessources.setTitle("Sélectionner le fichier des ressources");
        choixRessources.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Fichiers texte", "*.txt")
        );
        
        File ressources = choixRessources.showOpenDialog(cheminRessources.getScene().getWindow());
        if (ressources != null) {
            config.setFichierRessources(ressources.getAbsolutePath());
            cheminRessources.setText(ressources.getAbsolutePath());
        }
    }
    
    /**
     * Ouvre un sélecteur de fichier pour choisir l'emplacement de sortie des métriques
     */
    @FXML
    private void actionChoisirMetriques() {
        FileChooser choixMetriques = new FileChooser();
        choixMetriques.setTitle("Sélectionner le fichier de sortie des métriques");
        choixMetriques.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Fichiers texte", "*.txt")
        );
        
        File metriques = choixMetriques.showSaveDialog(cheminBackupMetrique.getScene().getWindow());
        if (metriques != null) {
            config.setFichierMetriques(metriques.getAbsolutePath());
            cheminBackupMetrique.setText(metriques.getAbsolutePath());
        }
    }
    
    /**
     * Sauvegarde la configuration et lance l'exécution du script Python
     * Vérification de la config avant de continuer
     */
    @FXML
    private void actionSauvegarder() {
        String erreurs = validerConfiguration();
        
        if (!erreurs.isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Configuration incomplète");
            alert.setHeaderText("Veuillez corriger les erreurs suivantes :");
            alert.setContentText(erreurs);
            alert.showAndWait();
        } else {
            // Ici la chaîne des algorithmes
            StringBuilder algos = new StringBuilder();
            if (FIFO.isSelected()) algos.append("FIFO;");
            if (PRIORITE.isSelected()) algos.append("PRIORITE;");
            if (RR.isSelected()) algos.append("RR;");
            
            if (algos.length() > 0) {
                algos.setLength(algos.length() - 1);
                config.setAlgorithme(algos.toString());
            }
            
            // Gérer le quantum
            if (RR.isSelected() && !txtQuantum.getText().isEmpty()) {
                try {
                    config.setQuantum(Integer.parseInt(txtQuantum.getText()));
                } catch (NumberFormatException e) {
                    config.setQuantum(2); // quantum par défaut s'il est null (impossible normalement mais bon...)
                }
            } 

            // Toute la manipulation pour créer un fichier de config et exécuter le script Python
            try {
                creerFichierConfig();
                executerPython();
                List<Metrique> metriques = lireMetriquesDepuisFichier(config.getFichierMetriques());
                BarChart<String, Number> chart = creerDiagramme(metriques);
                graphiqueBox.getChildren().setAll(chart);

            } catch (IOException e) {
                System.err.println("Erreur lors de l'exécution de l'ordonnanceur main.py : " + e.getMessage());
            }
        }
    }

    /**
     * Crée le fichier config.txt avec les paramètres de configuration
     * Le fichier est créé dans un répertoire temporaire
     * 
     * @throws IOException s'il y a une erreur d'écriture
     */
    private void creerFichierConfig() throws IOException {
        // Créer un répertoire temporaire pour le fichier config
        Path tempConfig = Files.createTempDirectory("config python");
        Path cheminConfig = tempConfig.resolve("config.txt");
        
        // Ici toute la partie pour écrire le fichier config.txt (de la même manière que celui de Jinhai (de base))
        try (PrintWriter writer = new PrintWriter(cheminConfig.toFile())) {
            writer.println("# Fichier de configuration pour l'ordonnanceur Python");
            writer.println();
            writer.println("# Chemin vers le fichier CSV des processus");
            writer.println("process_file = " + config.getFichierProcessus());
            writer.println();
            writer.println("# Chemin vers le fichier qui contient les ressources disponibles");
            writer.println("ressources_file = " + config.getFichierRessources());
            writer.println();
            writer.println("# Fichiers où stocker les résultats pour chaque algorithme");
            
            // Générer les noms de fichiers de résultats basés sur le fichier de métriques
            String baseMetrics = config.getFichierMetriques();
            String dir = new File(baseMetrics).getParent();
            if (dir == null) dir = ".";
            
            writer.println("result_file_fifo = " + dir + File.separator + "resultat_fifo.csv");
            writer.println("result_file_rr = " + dir + File.separator + "resultat_rr.csv");
            writer.println("result_file_priorite = " + dir + File.separator + "resultat_priorite.csv");
            writer.println();
            writer.println("# Fichier où stocker les métriques globales");
            writer.println("metrics_file = " + config.getFichierMetriques());
            writer.println();
            writer.println("# Algorithmes à exécuter (FIFO, RR et PRIORITE)");
            writer.println("algorithms = " + config.getAlgorithme());
            writer.println();
            writer.println("# Quantum pour Round Robin (en unités de temps)");
            writer.println("quantum = " + config.getQuantum());
        }
        
        // Stocker le chemin pour l'utiliser dans executerPython
        System.setProperty("python.config.path", cheminConfig.toString());
    }
    
    /**
     * Exécute le script Python main.py
     * Extrait les ressources Python du .JAR dans un répertoire temporaire
     * 
     * @throws IOException s'il y a une erreur lors de l'exécution
     */
    private void executerPython() throws IOException {

        // Récupère le script 'python/main.py' depuis les ressources 
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("python/main.py")) {
            if (inputStream == null) {
                throw new IOException("Impossible de trouver main.py dans les ressources.");
            }

            // Lancer uniquement si au moins un algorithme est sélectionné (encore une fois impossible mais bon...)
            boolean algoSelected = FIFO.isSelected() || PRIORITE.isSelected() || RR.isSelected();
            if (!algoSelected) {
                return;
            }

            ProcessBuilder pb = new ProcessBuilder("python", "-");
            Process process = pb.start();

            // Consommer stdout et stderr du processus pour éviter les blocages (au secours hahaha)
            Thread stdoutReader = new Thread(() -> {
                try (InputStream is = process.getInputStream()) {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = is.read(buf)) != -1) {
                        System.out.write(buf, 0, r);
                    }
                } catch (IOException ignored) {
                }
            }, "python-stdout-reader");
            stdoutReader.setDaemon(true);
            stdoutReader.start();

            // Créer un répertoire temporaire pour y extraire tous les modules Python du .JAR
            Path tempPython = Files.createTempDirectory("python-modules");
            tempPython.toFile().deleteOnExit();
            
            // Extraire tous les fichiers .py du dossier python/ du .JAR
            String[] modulesPython = {
                "python/entre_sortie.py",
                "python/ordonnanceurs.py",
                "python/metrique.py"
            };
            
            for (String cheminPython : modulesPython) {
                try (InputStream res = getClass().getClassLoader().getResourceAsStream(cheminPython)) {
                    if (res != null) {
                        String fileName = cheminPython.substring(cheminPython.lastIndexOf('/') + 1);
                        Path targetFile = tempPython.resolve(fileName);
                        Files.copy(res, targetFile, StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }

            // Copier aussi le fichier config.txt créé dynamiquement
            String configConfig = System.getProperty("python.config.path");
            if (configConfig != null) {
                Path sourceConfig = Path.of(configConfig);
                Path targetConfig = tempPython.resolve("config.txt");
                Files.copy(sourceConfig, targetConfig, StandardCopyOption.REPLACE_EXISTING);
            }

            // Envoyer le contenu du script dans stdin du process avec sys.path configuré
            try (OutputStream procIn = process.getOutputStream()) {
                // Injecter du code Python pour configurer sys.path
                String setupCode = String.format(
                    "import sys%nsys.path.insert(0, '%s')%n",
                    tempPython.toString().replace("\\", "\\\\")
                );
                procIn.write(setupCode.getBytes());
                procIn.flush();
                
                // Puis envoyer le contenu du script main.py
                byte[] buffer = new byte[8192];
                int len;
                while ((len = inputStream.read(buffer)) != -1) {
                    procIn.write(buffer, 0, len);
                }
                procIn.flush();
            }
        }
    }

    /**
     * Valide la config actuelle en vérifiant que tous les champs requis sont remplis et corrects
     * 
     * @return une chaîne contenant les erreurs de validation, elle est cependant vide si aucune erreur
     */
    private String validerConfiguration() {
        StringBuilder erreurs = new StringBuilder();
        
        if (config.getFichierProcessus().isEmpty()) {
            erreurs.append("- Veuillez sélectionner le fichier des processus\n");
        }
        
        if (config.getFichierRessources().isEmpty()) {
            erreurs.append("- Veuillez sélectionner le fichier des ressources\n");
        }
        
        if (config.getFichierMetriques().isEmpty()) {
            erreurs.append("- Veuillez sélectionner le fichier de sortie des métriques\n");
        }
        
        if (!FIFO.isSelected() && !PRIORITE.isSelected() && !RR.isSelected()) {
            erreurs.append("- Veuillez sélectionner au moins un algorithme d'ordonnancement\n");
        }
        
        if (RR.isSelected()) {
            if (txtQuantum.getText().isEmpty()) {
                erreurs.append("- Veuillez spécifier un quantum pour l'algorithme Round Robin\n");
            } else {
                try {
                    int quantum = Integer.parseInt(txtQuantum.getText());
                    if (quantum <= 0) {
                        erreurs.append("- Le quantum doit être un entier positif\n");
                    }
                } catch (NumberFormatException e) {
                    erreurs.append("- Le quantum doit être un nombre entier valide\n");
                }
            }
        } 
        return erreurs.toString();
    }
    
    /**
     * Retourne la configuration de l'ordonnanceur
     * 
     * @return la configuration de l'ordonnanceur
     */
    public ConfigOrdonnanceur getConfig() {
        return config;
    }

    private List<Metrique> lireMetriquesDepuisFichier(String fichier) {
    List<Metrique> metriques = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(fichier))) {
        String ligne;
        String algo = null;
        double attente = 0, reponse = 0, makespan = 0;

        while ((ligne = br.readLine()) != null) {
            ligne = ligne.trim();
            if (ligne.startsWith("==")) {
                algo = ligne.replace("==", "").replace("==", "").trim();
            } else if (ligne.startsWith("attente_moy:")) {
                attente = Double.parseDouble(ligne.split(":")[1].trim());
            } else if (ligne.startsWith("reponse_moy:")) {
                reponse = Double.parseDouble(ligne.split(":")[1].trim());
            } else if (ligne.startsWith("makespan:")) {
                makespan = Double.parseDouble(ligne.split(":")[1].trim());
                // Quand on a fini un bloc, on ajoute
                if (algo != null) {
                    metriques.add(new Metrique(algo, attente, reponse, makespan));
                }
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return metriques;
}

private BarChart<String, Number> creerDiagramme(List<Metrique> metriques) {
    CategoryAxis xAxis = new CategoryAxis();
    NumberAxis yAxis = new NumberAxis();
    BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);

    chart.setTitle("Comparaison des Ordonnanceurs");
    xAxis.setLabel("Algorithmes");
    yAxis.setLabel("Valeurs");

    XYChart.Series<String, Number> attenteSeries = new XYChart.Series<>();
    attenteSeries.setName("Attente Moyenne");

    XYChart.Series<String, Number> reponseSeries = new XYChart.Series<>();
    reponseSeries.setName("Réponse Moyenne");

    XYChart.Series<String, Number> makespanSeries = new XYChart.Series<>();
    makespanSeries.setName("Makespan");

    for (Metrique m : metriques) {
        attenteSeries.getData().add(new XYChart.Data<>(m.algo, m.attente));
        reponseSeries.getData().add(new XYChart.Data<>(m.algo, m.reponse));
        makespanSeries.getData().add(new XYChart.Data<>(m.algo, m.makespan));
    }

    chart.getData().addAll(attenteSeries, reponseSeries, makespanSeries);
    return chart;
}


}