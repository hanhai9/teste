package javadevapp.view;

class Metrique {
    String algo;
    double attente;
    double reponse;
    double makespan;

    Metrique(String algo, double attente, double reponse, double makespan) {
        this.algo = algo;
        this.attente = attente;
        this.reponse = reponse;
        this.makespan = makespan;
    }
}
