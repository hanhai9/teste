"""Module entre_sortie

Ce module fournit des fonctions simples de lecture/écriture pour le projet:
- lire_processus: lire la liste des processus depuis un fichier CSV
- lire_config: lire les paires cle/valeur depuis un fichier de configuration
- ecrire_resultats: écrire les segments d'exécution (pid, debut, fin, cpu)
- ecrire_metriques: append des métriques calculées dans un fichier

Les fonctions sont volontairement concises et utilisent des opérations basiques
de lecture/écriture de fichiers. Les valeurs retournées sont des structures
Python simples (listes et dictionnaires) adaptées au reste du projet.
"""

def lire_processus(fichier):
    """Lire les processus depuis un fichier CSV.

    Le fichier est attendu avec une première ligne d'en-tête. Chaque ligne
    suivante contient: id,arrivee,duree,ram,priorite,deadline

    Args:
        fichier (str): chemin vers le fichier CSV des processus.

    Returns:
        list[dict]: liste de dictionnaires représentant les processus.
    """
    liste = []
    f = open(fichier, "r")
    lignes = f.readlines()

    # ignorer la première ligne (en-tête)
    for l in lignes[1:]:
        l = l.strip()
        if l != "":
            p = {}
            pieces = l.split(",")
            # mapping explicite des champs
            p["id"] = pieces[0]
            p["arrivee"] = int(pieces[1])
            p["duree"] = int(pieces[2])
            p["ram"] = int(pieces[3])
            p["priorite"] = int(pieces[4])
            p["deadline"] = int(pieces[5])
            liste.append(p)
    f.close()
    return liste


def lire_config(fichier):
    """Lire un fichier de configuration simple cle=valeur.

    Les lignes sans "=" sont ignorées. Les valeurs sont retournées en
    tant que chaînes (le code appelant peut les convertir si besoin).
    """
    config = {}
    f = open(fichier, "r")
    lignes = f.readlines()
    for l in lignes:
        l = l.strip()
        if "=" in l:
            parts = l.split("=")
            cle = parts[0].strip()
            val = parts[1].strip()
            config[cle] = val
    f.close()
    return config


def ecrire_resultats(fichier, res):
    """Écrire les résultats d'ordonnancement dans un fichier.

    Chaque élément de res est attendu comme un tuple (pid, debut, fin[, cpu]).
    Le fichier est écrasé (mode 'w').
    """
    f = open(fichier, "w")
    for s in res:
        pid = s[0]
        debut = s[1]
        fin = s[2]
        if len(s) > 3:
            cpu = s[3]
        else:
            cpu = ""
        ligne = str(pid) + ";" + str(debut) + ";" + str(fin) + ";" + str(cpu) + "\n"
        f.write(ligne)
    f.close()

def lire_ressources(fichier):
    """Lire le fichier des ressources (cpu et ram)."""
    ressources = {}
    f = open(fichier, "r")
    lignes = f.readlines()
    for l in lignes:
        l = l.strip()
        if "=" in l:
            cle, val = l.split("=")
            ressources[cle.strip()] = int(val.strip())
    f.close()
    return ressources



def ecrire_metriques(fichier, nom_algo, attente, reponse, makespan):
    """Ajouter (append) les métriques calculées au fichier de sortie.

    Le format est simple et lisible pour inspection manuelle.
    """
    f = open(fichier, "a")
    f.write("== " + nom_algo + " ==\n")
    f.write("attente_moy: " + str(attente) + "\n")
    f.write("reponse_moy: " + str(reponse) + "\n")
    f.write("makespan: " + str(makespan) + "\n")
    f.write("\n")
    f.close()
