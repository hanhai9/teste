package javadevapp.service;

import javadevapp.model.Metrique;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MetriqueService {

    public List<Metrique> lireMetriquesDepuisFichier(String fichier) {
        List<Metrique> metriques = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fichier))) {
            String ligne;
            String algo = null;
            double attente = 0, reponse = 0, makespan = 0;

            while ((ligne = br.readLine()) != null) {
                ligne = ligne.trim();
                if (ligne.startsWith("==")) {
                    algo = ligne.replace("==", "").trim();
                } else if (ligne.startsWith("attente_moy:")) {
                    attente = Double.parseDouble(ligne.split(":")[1].trim());
                } else if (ligne.startsWith("reponse_moy:")) {
                    reponse = Double.parseDouble(ligne.split(":")[1].trim());
                } else if (ligne.startsWith("makespan:")) {
                    makespan = Double.parseDouble(ligne.split(":")[1].trim());
                    if (algo != null) {
                        metriques.add(new Metrique(algo, attente, reponse, makespan));
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return metriques;
    }

    public BarChart<String, Number> creerDiagramme(List<Metrique> metriques) {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);

        chart.setTitle("Comparaison des Ordonnanceurs");
        xAxis.setLabel("Algorithmes");
        yAxis.setLabel("Valeurs");

        XYChart.Series<String, Number> attenteSeries = new XYChart.Series<>();
        attenteSeries.setName("Attente Moyenne");

        XYChart.Series<String, Number> reponseSeries = new XYChart.Series<>();
        reponseSeries.setName("Réponse Moyenne");

        XYChart.Series<String, Number> makespanSeries = new XYChart.Series<>();
        makespanSeries.setName("Makespan");

        for (Metrique m : metriques) {
            attenteSeries.getData().add(new XYChart.Data<>(m.getAlgo(), m.getAttente()));
            reponseSeries.getData().add(new XYChart.Data<>(m.getAlgo(), m.getReponse()));
            makespanSeries.getData().add(new XYChart.Data<>(m.getAlgo(), m.getMakespan()));
        }

        chart.getData().addAll(attenteSeries, reponseSeries, makespanSeries);
        return chart;
    }
}
