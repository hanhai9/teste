package javadevapp.service;

import java.io.*;

public class PythonExecut {

    public static void executerPython() throws IOException, InterruptedException {
        try (InputStream inputStream = PythonExecut.class.getClassLoader().getResourceAsStream("python/main.py")) {
            if (inputStream == null) throw new IOException("main.py introuvable");

            ProcessBuilder pb = new ProcessBuilder("python", "-");
            Process process = pb.start();

            // Threads stdout/stderr
            new Thread(() -> lireFlux(process.getInputStream(), System.out)).start();
            new Thread(() -> lireFlux(process.getErrorStream(), System.err)).start();

            // Injection du script
            try (OutputStream procIn = process.getOutputStream()) {
                procIn.write(("import sys\n").getBytes());
                procIn.flush();

                byte[] buffer = new byte[8192];
                int len;
                while ((len = inputStream.read(buffer)) != -1) {
                    procIn.write(buffer, 0, len);
                }
                procIn.flush();
            }

            int exitCode = process.waitFor();
            System.out.println("Python terminé avec code " + exitCode);
        }
    }

    private static void lireFlux(InputStream is, PrintStream out) {
        try (is) {
            byte[] buf = new byte[8192];
            int r;
            while ((r = is.read(buf)) != -1) out.write(buf, 0, r);
        } catch (IOException ignored) {}
    }
}
