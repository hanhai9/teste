"""Point d'entrée du petit simulateur d'ordonnancement.

Ce fichier lit la configuration, charge les processus et exécute les
algorithmes demandés. Les résultats et métriques sont écrits
dans les fichiers indiqués par la configuration.
"""

import os
import sys
from entre_sortie import lire_config, lire_processus, ecrire_resultats, ecrire_metriques , lire_ressources
from ordonnanceurs import fifo, priorite, round_robin
from metrique import calculer_metriques


def main():
    """Fonction principale: orchestrer la lecture, l'exécution et l'écriture.

    Le comportement est piloté par `config.txt` (clé/valeur). Les clés
    attendues incluent au minimum: process_file, result_file_fifo,
    result_file_rr, metrics_file, algorithms. Le quantum est optionnel.
    """
    # afficher le répertoire courant pour information
    print("Répertoire courant :", os.getcwd())

    # Déterminer le chemin du fichier config
    if len(sys.path) > 0 and os.path.isdir(sys.path[0]):
        script_dir = sys.path[0]
    else:
        script_dir = os.getcwd()
    
    config_path = os.path.join(script_dir, "config.txt")

    # Vérifier si le fichier existe, sinon essayer le répertoire courant
    if not os.path.exists(config_path):
        config_path = "config.txt"
        print(f"Config non trouvé dans {script_dir}, essai avec chemin relatif")
    
    print(f"Lecture du fichier de configuration : {config_path}")

    # lire la config
    config = lire_config(config_path)
    file_proc = config["process_file"]
    file_res_fifo = config["result_file_fifo"]
    file_res_rr = config["result_file_rr"]
    file_res_priorite = config["result_file_priorite"]
    file_metrics = config["metrics_file"]
    quantum = int(config.get("quantum", "2"))
    algo = config["algorithms"].split(",")

    # TESTS ALEXIS
    # print("test main", config)
    # print(file_proc, file_res_fifo, file_res_rr, file_metrics, algo)

    # lire les processus
    proc = lire_processus(file_proc)

    # lire les processus et les ressources
    proc = lire_processus(file_proc)
    ressources = lire_ressources(config["ressources_file"])
    nb_cpu = ressources["cpu"]
    ram_totale = ressources["ram"]
    
    # exécuter FIFO si demandé
    if "FIFO" in algo:
        r = fifo(proc, nb_cpu, ram_totale)
        ecrire_resultats(file_res_fifo, r)
        att, rep, mk = calculer_metriques(r, proc)
        ecrire_metriques(file_metrics, "FIFO", att, rep, mk)

    # exécuter Round Robin si demandé
    if "RR" in algo:
        r = round_robin(proc, quantum, nb_cpu, ram_totale)
        ecrire_resultats(file_res_rr, r)
        att, rep, mk = calculer_metriques(r, proc)
        ecrire_metriques(file_metrics, "RR", att, rep, mk)

    if "PRIORITE" in algo:
        r = priorite(proc, nb_cpu, ram_totale)
        ecrire_resultats(file_res_priorite, r)
        att, rep, mk = calculer_metriques(r, proc)
        ecrire_metriques(file_metrics, "PRIORITE", att, rep, mk)

    print("Fin du programme python !")


if __name__ == "__main__":
    main()
