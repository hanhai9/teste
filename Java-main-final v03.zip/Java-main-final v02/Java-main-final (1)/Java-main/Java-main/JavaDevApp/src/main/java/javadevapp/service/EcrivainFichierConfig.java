package javadevapp.service;

import javadevapp.model.ConfigOrdonnanceur;
import java.io.*;
import java.nio.file.*;

/**
 * Classe utilitaire responsable de la création du fichier de configuration
 * (config.txt) utilisé par le script Python.
 */
public class EcrivainFichierConfig {

    /**
     * Crée un fichier temporaire config.txt contenant les paramètres de l'ordonnanceur.
     *
     * @param config la configuration de l'ordonnanceur
     * @return le chemin du fichier config.txt créé
     * @throws IOException si une erreur survient lors de l'écriture du fichier
     */
    public static Path creerFichierConfig(ConfigOrdonnanceur config) throws IOException {
        Path tempConfig = Files.createTempDirectory("config_python");
        Path cheminConfig = tempConfig.resolve("config.txt");

        try (PrintWriter writer = new PrintWriter(cheminConfig.toFile())) {
            writer.println("process_file = " + config.getFichierProcessus());
            writer.println("ressources_file = " + config.getFichierRessources());
            writer.println("metrics_file = " + config.getFichierMetriques());
            writer.println("algorithms = " + config.getAlgorithme());
            writer.println("quantum = " + (config.getQuantum() != null ? config.getQuantum() : 2));
        }

        System.setProperty("python.config.path", cheminConfig.toString());
        return cheminConfig;
    }
}
