package javadevapp.view;

import javadevapp.model.ConfigOrdonnanceur;
import javadevapp.model.Metrique;
import javadevapp.service.ConfigValidator;
import javadevapp.service.MetriqueService;
import javadevapp.service.EcrivainFichierConfig;
import javadevapp.service.PythonExecut;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.layout.VBox;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Contrôleur principal de l'interface de configuration de l'ordonnanceur.
 * <p>
 * Responsabilités :
 * <ul>
 *   <li>Gestion des sélecteurs de fichiers</li>
 *   <li>Validation de la configuration via {@link ConfigValidator}</li>
 *   <li>Création du fichier config.txt via {@link EcrivainFichierConfig}</li>
 *   <li>Exécution du script Python via {@link ExecuteurPython}</li>
 *   <li>Lecture et affichage des métriques via {@link MetriqueService}</li>
 * </ul>
 */
public class ConfigOrdonnanceurController implements Initializable {

    @FXML private Label cheminProcess;
    @FXML private VBox graphiqueBox;
    @FXML private Label cheminRessources;
    @FXML private Label cheminBackupMetrique;
    @FXML private CheckBox FIFO;
    @FXML private CheckBox PRIORITE;
    @FXML private CheckBox RR;
    @FXML private TextField txtQuantum;

    private ConfigOrdonnanceur config;

    public void ControleurConfigOrdonnanceur() {
        this.config = new ConfigOrdonnanceur();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cheminProcess.setText("Aucun fichier sélectionné");
        cheminRessources.setText("Aucun fichier sélectionné");
        cheminBackupMetrique.setText("Aucun fichier sélectionné");
        txtQuantum.setDisable(true);

        RR.selectedProperty().addListener((obs, oldVal, newVal) -> {
            txtQuantum.setDisable(!newVal);
            if (!newVal) txtQuantum.clear();
        });
    }

    @FXML private void actionChoisirProcessus() {
        FileChooser choixProcess = new FileChooser();
        choixProcess.setTitle("Sélectionner le fichier des processus");
        choixProcess.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Fichiers CSV", "*.csv")
        );
        File process = choixProcess.showOpenDialog(cheminProcess.getScene().getWindow());
        if (process != null) {
            config.setFichierProcessus(process.getAbsolutePath());
            cheminProcess.setText(process.getAbsolutePath());
        }
    }

    @FXML private void actionChoisirRessources() {
        FileChooser choixRessources = new FileChooser();
        choixRessources.setTitle("Sélectionner le fichier des ressources");
        choixRessources.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Fichiers texte", "*.txt")
        );
        File ressources = choixRessources.showOpenDialog(cheminRessources.getScene().getWindow());
        if (ressources != null) {
            config.setFichierRessources(ressources.getAbsolutePath());
            cheminRessources.setText(ressources.getAbsolutePath());
        }
    }

    @FXML private void actionChoisirMetriques() {
        FileChooser choixMetriques = new FileChooser();
        choixMetriques.setTitle("Sélectionner le fichier de sortie des métriques");
        choixMetriques.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Fichiers texte", "*.txt")
        );
        File metriques = choixMetriques.showSaveDialog(cheminBackupMetrique.getScene().getWindow());
        if (metriques != null) {
            config.setFichierMetriques(metriques.getAbsolutePath());
            cheminBackupMetrique.setText(metriques.getAbsolutePath());
        }
    }

    @FXML private void actionSauvegarder() {
        ConfigValidator validator = new ConfigValidator();
        String erreurs = validator.validerConfiguration(
            config,
            FIFO.isSelected(),
            PRIORITE.isSelected(),
            RR.isSelected(),
            txtQuantum.getText()
        );

        if (!erreurs.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Configuration incomplète");
            alert.setHeaderText("Veuillez corriger les erreurs suivantes :");
            alert.setContentText(erreurs);
            alert.showAndWait();
            return;
        }

        StringBuilder algos = new StringBuilder();
        if (FIFO.isSelected()) algos.append("FIFO,");
        if (PRIORITE.isSelected()) algos.append("PRIORITE,");
        if (RR.isSelected()) algos.append("RR,");
        if (algos.length() > 0) {
            algos.setLength(algos.length() - 1);
            config.setAlgorithme(algos.toString());
        }

        if (RR.isSelected() && !txtQuantum.getText().isEmpty()) {
            try {
                config.setQuantum(Integer.parseInt(txtQuantum.getText()));
            } catch (NumberFormatException e) {
                config.setQuantum(2);
            }
        }

        try {
            EcrivainFichierConfig.creerFichierConfig(config);

            try (PrintWriter pw = new PrintWriter(config.getFichierMetriques())) {}

            new Thread(() -> {
                try {
                    PythonExecut.executerPython();

                    MetriqueService metriqueService = new MetriqueService();
                    List<Metrique> metriques = metriqueService.lireMetriquesDepuisFichier(config.getFichierMetriques());
                    BarChart<String, Number> chart = metriqueService.creerDiagramme(metriques);

                    javafx.application.Platform.runLater(() -> graphiqueBox.getChildren().setAll(chart));
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();

        } catch (IOException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
    }

    public ConfigOrdonnanceur getConfig() {
        return config;
    }
}
