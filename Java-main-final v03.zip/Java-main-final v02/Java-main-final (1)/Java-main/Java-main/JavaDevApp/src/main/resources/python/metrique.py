"""Module metrique

Contient les fonctions de calcul des métriques d'ordonnancement.
La fonction principale est `calculer_metriques` qui retourne:
    (attente_moy, reponse_moy, makespan)

Les métriques sont calculées à partir de la liste des segments
`res` [(pid, debut, fin), ...] et de la liste des definitions de
processus (dictionnaires contenant au moins 'id' et 'arrivee').
"""


def calculer_metriques(res, processus):
    """Calculer les métriques d'ordonnancement.

    Args:
        res (list of tuple): liste des segments d'exécution (pid, debut, fin)
        processus (list of dict): descriptions des processus (avec 'id' et 'arrivee')

    Returns:
        tuple: (attente_moy, reponse_moy, makespan)
    """
    # initialiser les totaux à 0
    attente_total = 0
    reponse_total = 0

    # parcourir tous les processus
    for p in processus:
        pid = p["id"]

        # créer des listes pour stocker tous les débuts et fins du processus
        debut_list = []
        fin_list = []

        # parcourir tous les segments exécutés
        for s in res:
            # vérifier si le segment correspond au processus courant
            if s[0] == pid:
                debut_list.append(s[1])  # ajouter le début
                fin_list.append(s[2])    # ajouter la fin

        # calculer les métriques pour ce processus
        if len(debut_list) > 0:
            # premier début effectif (peut y avoir plusieurs segments)
            debut_eff = min(debut_list)
            # fin effective = maximum des fins des segments
            fin_eff = max(fin_list)

            # calcul de l'attente et du temps de réponse
            attente = debut_eff - p["arrivee"]
            reponse = fin_eff - p["arrivee"]

            attente_total += attente
            reponse_total += reponse

    # nombre de processus
    n = len(processus)

    # calcul des moyennes
    if n > 0:
        attente_moy = attente_total / n
        reponse_moy = reponse_total / n
    else:
        attente_moy = 0
        reponse_moy = 0

    # calcul du makespan = temps de fin du dernier processus
    makespan = 0
    for s in res:
        if s[2] > makespan:
            makespan = s[2]

    # retourner les résultats
    return attente_moy, reponse_moy, makespan
