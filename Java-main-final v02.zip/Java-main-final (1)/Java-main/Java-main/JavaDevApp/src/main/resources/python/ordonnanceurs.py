"""
Module ordonnanceurs

Implémente des politiques d'ordonnancement simples utilisées par le
projet: FIFO, Round-Robin et Priorité.
Les fonctions acceptent une liste de processus (dictionnaires avec au moins
'id','arrivee','duree', et éventuellement 'ram','priorite') et
retournent une liste de tuples (pid, debut, fin, cpu) représentant les
segments d'exécution.
"""

def fifo(processus, nb_cpu=1, ram_totale=123):
    """Ordonnancement FIFO (first-in, first-out)."""
    temps = 0
    res = []
    cpu = 0
    for p in processus:
        debut = max(temps, p["arrivee"])
        if p.get("ram", 0) <= ram_totale:
            fin = debut + p["duree"]
            res.append((p["id"], debut, fin, cpu))
            temps = fin
            cpu = (cpu + 1) % nb_cpu
        else:
            print(f"Processus {p['id']} ignoré (RAM insuffisante)")
    return res

def round_robin(processus, quantum, nb_cpu=1, ram_totale=123):
    duree_restante = {p["id"]: p["duree"] for p in processus}
    temps = 0
    res = []
    file = processus.copy()
    cpu = 0

    while len(duree_restante) > 0:
        for p in file.copy():
            pid = p["id"]
            if p["arrivee"] <= temps and pid in duree_restante:
                if p["ram"] <= ram_totale:
                    d = min(quantum, duree_restante[pid])
                    debut = temps
                    fin = debut + d
                    res.append((pid, debut, fin, cpu))
                    temps += d
                    duree_restante[pid] -= d
                    cpu = (cpu + 1) % nb_cpu
                    if duree_restante[pid] <= 0:
                        del duree_restante[pid]
                else:
                    print(f"Processus {pid} ignoré (RAM insuffisante)")
                    del duree_restante[pid]

        if all(p["arrivee"] > temps for p in file if p["id"] in duree_restante):
            temps += 1

    return res


def priorite(processus, nb_cpu=1, ram_totale=123):
    fich_attente = processus.copy()
    res = []
    temps = 0
    cpu = 0

    while fich_attente:
        max_p = fich_attente[0]
        for p in fich_attente:
            if p["priorite"] > max_p["priorite"]:
                max_p = p
        if max_p["ram"] <= ram_totale:
            debut = temps
            fin = debut + max_p["duree"]
            res.append((max_p["id"], debut, fin, cpu))
            temps = fin
            cpu = (cpu + 1) % nb_cpu
        else:
            print(f"Processus {max_p['id']} ignoré (RAM insuffisante)")
        fich_attente.remove(max_p)

    return res
