package javadevapp.view;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javadevapp.model.ConfigOrdonnanceur;
import javadevapp.model.Metrique;
import javadevapp.service.ConfigValidator;
import javadevapp.service.MetriqueService;

import java.io.File;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ConfigOrdonnanceurController implements Initializable {

    @FXML private Label cheminProcess;
    @FXML private Label cheminRessources;
    @FXML private Label cheminBackupMetrique;
    @FXML private VBox graphiqueBox;
    @FXML private CheckBox FIFO;
    @FXML private CheckBox PRIORITE;
    @FXML private CheckBox RR;
    @FXML private TextField txtQuantum;

    private ConfigOrdonnanceur config;
    private ConfigValidator validator;
    private MetriqueService metriqueService;

    public ConfigOrdonnanceurController() {
        this.config = new ConfigOrdonnanceur();
        this.validator = new ConfigValidator();
        this.metriqueService = new MetriqueService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cheminProcess.setText("Aucun fichier sélectionné");
        cheminRessources.setText("Aucun fichier sélectionné");
        cheminBackupMetrique.setText("Aucun fichier sélectionné");

        txtQuantum.setDisable(true);
        RR.selectedProperty().addListener((obs, oldVal, newVal) -> {
            txtQuantum.setDisable(!newVal);
            if (!newVal) txtQuantum.clear();
        });
    }

    @FXML
    private void actionChoisirProcessus() {
        FileChooser choixProcess = new FileChooser();
        choixProcess.setTitle("Sélectionner le fichier des processus");
        choixProcess.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers CSV", "*.csv"));
        File process = choixProcess.showOpenDialog(cheminProcess.getScene().getWindow());
        if (process != null) {
            config.setFichierProcessus(process.getAbsolutePath());
            cheminProcess.setText(process.getAbsolutePath());
        }
    }

    @FXML
    private void actionChoisirRessources() {
        FileChooser choixRessources = new FileChooser();
        choixRessources.setTitle("Sélectionner le fichier des ressources");
        choixRessources.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers texte", "*.txt"));
        File ressources = choixRessources.showOpenDialog(cheminRessources.getScene().getWindow());
        if (ressources != null) {
            config.setFichierRessources(ressources.getAbsolutePath());
            cheminRessources.setText(ressources.getAbsolutePath());
        }
    }

    @FXML
    private void actionChoisirMetriques() {
        FileChooser choixMetriques = new FileChooser();
        choixMetriques.setTitle("Sélectionner le fichier de sortie des métriques");
        choixMetriques.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers texte", "*.txt"));
        File metriques = choixMetriques.showSaveDialog(cheminBackupMetrique.getScene().getWindow());
        if (metriques != null) {
            config.setFichierMetriques(metriques.getAbsolutePath());
            cheminBackupMetrique.setText(metriques.getAbsolutePath());
        }
    }

    @FXML
    private void actionAfficherGraphique() {
        String erreurs = validator.validerConfiguration(config, FIFO.isSelected(), PRIORITE.isSelected(), RR.isSelected(), txtQuantum.getText());
        if (!erreurs.isEmpty()) {
            System.out.println("Erreurs : \n" + erreurs);
            return;
        }
        List<Metrique> metriques = metriqueService.lireMetriquesDepuisFichier(config.getFichierMetriques());
        BarChart<String, Number> chart = metriqueService.creerDiagramme(metriques);
        graphiqueBox.getChildren().setAll(chart);
    }
}
