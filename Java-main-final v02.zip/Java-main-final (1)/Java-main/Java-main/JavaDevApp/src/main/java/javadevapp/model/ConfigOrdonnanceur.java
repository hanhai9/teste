package javadevapp.model;

/**
 * Modèle représentant la configuration de l'ordonnanceur de processus.
 * Il contient les chemins des fichiers d'entrée/sortie et les paramètres d'exécution
 */
public class ConfigOrdonnanceur {
    
    private String fichierProcessus;
    private String fichierRessources;
    private String fichierMetriques;
    private String algorithme;
    private Integer quantum;
    
    /**
     * Constructeur par défaut
     */
    public ConfigOrdonnanceur() {
        this.fichierProcessus = "";
        this.fichierRessources = "";
        this.fichierMetriques = "";
        this.algorithme = "";
        this.quantum = null;
    }
    
    /**
     * Retourne le chemin du fichier des processus
     * 
     * @return le chemin du fichier CSV contenant les processus
     */
    public String getFichierProcessus() {
        return fichierProcessus;
    }
    
    /**
     * Définit le chemin du fichier des processus
     * 
     * @param fichierProcessus le chemin du fichier CSV contenant les processus
     */
    public void setFichierProcessus(String fichierProcessus) {
        this.fichierProcessus = fichierProcessus;
    }
    
    /**
     * Retourne le chemin du fichier ressources
     * 
     * @return le chemin du fichier contenant les ressources disponibles
     */
    public String getFichierRessources() {
        return fichierRessources;
    }
    
    /**
     * Définit le chemin du fichier ressources
     * 
     * @param fichierRessources le chemin du fichier contenant les ressources disponibles
     */
    public void setFichierRessources(String fichierRessources) {
        this.fichierRessources = fichierRessources;
    }
    
    /**
     * Retourne le chemin du fichier des métriques
     * 
     * @return le chemin du fichier de sortie des métriques
     */
    public String getFichierMetriques() {
        return fichierMetriques;
    }
    
    /**
     * Définit le chemin du fichier des métriques
     * 
     * @param fichierMetriques le chemin du fichier de sortie des métriques
     */
    public void setFichierMetriques(String fichierMetriques) {
        this.fichierMetriques = fichierMetriques;
    }
    
    /**
     * Retourne la ou les algorithmes d'ordonnancement sélectionnés
     * 
     * @return une chaîne contenant les algorithmes
     */
    public String getAlgorithme() {
        return algorithme;
    }
    
    /**
     * Définit les algorithmes d'ordonnancement
     * 
     * @param algorithme une chaîne contenant les algorithmes
     */
    public void setAlgorithme(String algorithme) {
        this.algorithme = algorithme;
    }
    
    /**
     * Retourne la valeur du quantum pour l'algorithme Round Robin
     * 
     * @return le quantum
     */
    public Integer getQuantum() {
        return quantum;
    }

    /**
     * Définit la valeur du quantum pour l'algorithme Round Robin
     * 
     * @param quantum le quantum
     */
    public void setQuantum(Integer quantum) {
        this.quantum = quantum;
    }
}