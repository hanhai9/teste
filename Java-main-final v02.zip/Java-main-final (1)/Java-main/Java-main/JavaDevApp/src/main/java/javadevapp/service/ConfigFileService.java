package javadevapp.service;

import javadevapp.model.ConfigOrdonnanceur;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class ConfigFileService {

    public void sauvegarder(ConfigOrdonnanceur config) {
        String dossierParam = System.getProperty("user.home") 
                + File.separator + "JavaDevApp" 
                + File.separator + "Param";

        File dir = new File(dossierParam);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        File fichierConfig = new File(dir, "config.txt");

        try (PrintWriter writer = new PrintWriter(fichierConfig)) {
            writer.println("fichierProcessus=" + config.getFichierProcessus());
            writer.println("fichierRessources=" + config.getFichierRessources());
            writer.println("fichierMetriques=" + config.getFichierMetriques());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
