package javadevapp;

import java.io.IOException;
// import javadevapp.view.ConfigOrdonnanceurController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

/**
 * Classe principale de l'application JavaFX pour la configuration de l'ordonnanceur de processus
 */
public class JavaDevApp extends Application {
    
    private BorderPane rootPane;
    private Stage primaryStage;
    
    /**
     * Démarre et charge l'interface graphique de l'application
     * 
     * @param primaryStage fenêtre principale de l'app
     */
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(JavaDevApp.class.getResource("view/ConfigOrdonnanceur.fxml"));
            
            this.rootPane = loader.load();
            
            Scene scene = new Scene(rootPane);
            
            primaryStage.setTitle("Configuration Ordonnanceur de Processus");
            primaryStage.setScene(scene);
            primaryStage.show();
            
        } catch (IOException e) {
            System.out.println("Erreur de chargement de l'interface : " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    /**
     * Ferme proprement l'app
     * 
     * @throws Exception si une erreur apparaît lors de la fermeture
     */
    @Override
    public void stop() throws Exception {
        this.primaryStage.close();
    }
    
    /**
     * Démarrage de l'application
     * 
     * @param args les arguments de ligne de commande
     */
    public static void main(String[] args) {
        launch(args);
    }
}