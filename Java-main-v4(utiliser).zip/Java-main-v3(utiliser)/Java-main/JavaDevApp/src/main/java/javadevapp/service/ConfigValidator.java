package javadevapp.service;

import javadevapp.model.ConfigOrdonnanceur;

public class ConfigValidator {

    public String validerConfiguration(ConfigOrdonnanceur config, boolean fifo, boolean priorite, boolean rr, String quantumText) {
        StringBuilder erreurs = new StringBuilder();

        if (config.getFichierProcessus().isEmpty()) {
            erreurs.append("- Veuillez sélectionner le fichier des processus\n");
        }
        if (config.getFichierRessources().isEmpty()) {
            erreurs.append("- Veuillez sélectionner le fichier des ressources\n");
        }
        if (config.getFichierMetriques().isEmpty()) {
            erreurs.append("- Veuillez sélectionner le fichier de sortie des métriques\n");
        }
        if (!fifo && !priorite && !rr) {
            erreurs.append("- Veuillez sélectionner au moins un algorithme d'ordonnancement\n");
        }
        if (rr) {
            if (quantumText.isEmpty()) {
                erreurs.append("- Veuillez spécifier un quantum pour Round Robin\n");
            } else {
                try {
                    int quantum = Integer.parseInt(quantumText);
                    if (quantum <= 0) erreurs.append("- Le quantum doit être positif\n");
                } catch (NumberFormatException e) {
                    erreurs.append("- Le quantum doit être un entier valide\n");
                }
            }
        }
        return erreurs.toString();
    }
}
